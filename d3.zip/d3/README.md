# Installation
> `npm install --save @types/d3`

# Summary
This package contains type definitions for d3JS (http://d3js.org/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3/v3.

### Additional Details
 * Last updated: Tue, 29 Sep 2020 22:01:29 GMT
 * Dependencies: none
 * Global values: `d3`

# Credits
These definitions were written by [Alex Ford](https://github.com/gustavderdrache), [Boris Yankov](https://github.com/borisyankov), [Matthias Jobst](https://github.com/MatthiasJobst), [Nithyanandam Venu](https://github.com/vbinithyanandamv), [Mihai Cherej](https://github.com/cronco), and [Nathan Bierema](https://github.com/Methuselah96).
