/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';
export { PlotlySharedModule as ɵa } from './lib/plotly-shared.module';

//# sourceMappingURL=angular-plotly.js.d.ts.map