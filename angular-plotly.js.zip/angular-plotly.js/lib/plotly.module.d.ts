import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from '@angular/common';
import * as ɵngcc2 from './plotly-shared.module';
export declare class PlotlyModule {
    static plotlyjs: any;
    constructor();
    private isValid;
    static ɵfac: ɵngcc0.ɵɵFactoryDeclaration<PlotlyModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDeclaration<PlotlyModule, never, [typeof ɵngcc1.CommonModule, typeof ɵngcc2.PlotlySharedModule], [typeof ɵngcc2.PlotlySharedModule]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDeclaration<PlotlyModule>;
}

//# sourceMappingURL=plotly.module.d.ts.map