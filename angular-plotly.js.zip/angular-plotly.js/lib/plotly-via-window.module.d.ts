import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from '@angular/common';
import * as ɵngcc2 from './plotly-shared.module';
export declare class PlotlyViaWindowModule {
    constructor();
    static ɵfac: ɵngcc0.ɵɵFactoryDeclaration<PlotlyViaWindowModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDeclaration<PlotlyViaWindowModule, never, [typeof ɵngcc1.CommonModule, typeof ɵngcc2.PlotlySharedModule], [typeof ɵngcc2.PlotlySharedModule]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDeclaration<PlotlyViaWindowModule>;
}

//# sourceMappingURL=plotly-via-window.module.d.ts.map