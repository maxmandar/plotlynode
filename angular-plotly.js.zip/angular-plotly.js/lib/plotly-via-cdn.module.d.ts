import { PlotlyService } from './plotly.service';
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from '@angular/common';
import * as ɵngcc2 from './plotly-shared.module';
export declare type PlotlyBundleName = 'basic' | 'cartesian' | 'geo' | 'gl3d' | 'gl2d' | 'mapbox' | 'finance';
export declare class PlotlyViaCDNModule {
    plotlyService: PlotlyService;
    private static plotlyBundle?;
    private static plotlyVersion;
    static plotlyBundleNames: PlotlyBundleName[];
    constructor(plotlyService: PlotlyService);
    static setPlotlyVersion(version: string): void;
    static setPlotlyBundle(bundle: PlotlyBundleName): void;
    static loadViaCDN(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDeclaration<PlotlyViaCDNModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDeclaration<PlotlyViaCDNModule, never, [typeof ɵngcc1.CommonModule, typeof ɵngcc2.PlotlySharedModule], [typeof ɵngcc2.PlotlySharedModule]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDeclaration<PlotlyViaCDNModule>;
}

//# sourceMappingURL=plotly-via-cdn.module.d.ts.map